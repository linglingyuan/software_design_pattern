package cn.edu.scau.sec.lingjielin.adapter;

public interface Target {
	void op(String calendarString);
}

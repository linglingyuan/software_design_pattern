package cn.edu.scau.sec.lingjielin.client;

public class Main {
	public static void main(String[] args) {
		testSingleton.runSingleton();
		testMutlition.runMutlition();
	}
}

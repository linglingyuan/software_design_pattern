package cn.edu.scau.sec.lingjielin.abstractFactory.abstractClass;

public abstract class Watch extends ConsumerElectronics{
	protected String productName = "手表";
}

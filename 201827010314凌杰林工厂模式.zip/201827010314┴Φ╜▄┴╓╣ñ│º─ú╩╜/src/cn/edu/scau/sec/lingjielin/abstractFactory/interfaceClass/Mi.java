package cn.edu.scau.sec.lingjielin.abstractFactory.interfaceClass;

public interface Mi extends Brand{
	public static final String name = "小米";
}

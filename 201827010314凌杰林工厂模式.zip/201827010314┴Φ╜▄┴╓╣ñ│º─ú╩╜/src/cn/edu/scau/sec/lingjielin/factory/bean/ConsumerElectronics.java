package cn.edu.scau.sec.lingjielin.factory.bean;

public interface ConsumerElectronics {
	void recreation();
}

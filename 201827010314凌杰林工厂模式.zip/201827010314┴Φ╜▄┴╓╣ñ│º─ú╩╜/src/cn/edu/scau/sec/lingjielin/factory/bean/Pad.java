package cn.edu.scau.sec.lingjielin.factory.bean;

public class Pad implements ConsumerElectronics {

	@Override
	public void recreation() {
		// TODO Auto-generated method stub
		System.out.println("使用平板娱乐");
	}
	
}

package cn.edu.scau.sec.lingjielin.factory.bean;

public class Watch implements ConsumerElectronics{

	@Override
	public void recreation() {
		// TODO Auto-generated method stub
		System.out.println("使用手表娱乐");
	}

}

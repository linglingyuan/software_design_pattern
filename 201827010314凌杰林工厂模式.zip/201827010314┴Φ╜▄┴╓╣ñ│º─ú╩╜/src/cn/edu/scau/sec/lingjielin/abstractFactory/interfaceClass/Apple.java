package cn.edu.scau.sec.lingjielin.abstractFactory.interfaceClass;

public interface Apple extends Brand{
	public static final String name = "苹果";
}

package cn.edu.scau.sec.lingjielin.abstractFactory.interfaceClass;

public interface Huawei extends Brand{
	public static final String name = "华为";
}

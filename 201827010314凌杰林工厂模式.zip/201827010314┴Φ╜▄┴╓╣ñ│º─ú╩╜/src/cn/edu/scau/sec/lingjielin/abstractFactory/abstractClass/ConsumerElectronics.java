package cn.edu.scau.sec.lingjielin.abstractFactory.abstractClass;
/*
 * 将电子产品的种类设计成抽象类ConsumerElectronics
 * 
 */
public abstract class ConsumerElectronics {
	abstract public void recreation();
}

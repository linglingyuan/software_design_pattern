package cn.edu.scau.sec.lingjielin.abstractFactory.abstractClass;

public abstract class Pad extends ConsumerElectronics{
	protected String productName = "平板";
}

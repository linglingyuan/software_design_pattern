package cn.edu.scau.sec.lingjielin.abstractFactory.interfaceClass;

/*
 * 品牌接口
 */
public interface Brand {
	
}
